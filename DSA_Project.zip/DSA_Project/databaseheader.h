#ifndef DATABASEHEADER_H
#define DATABASEHEADER_H

#include <QSqlDatabase>
#include <QSqlDriver>
#include <QSqlError>
#include <QDebug>
#include <QSqlTableModel>
#include <QFileInfo>
#include <QtSql>

#endif // DATABASEHEADER_H
